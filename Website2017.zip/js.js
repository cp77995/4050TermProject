function reverseElementOrder() {
    var elem = $('#tn'), 
        elemItems = elem.children('.right');
    elem.append(elemItems.get().reverse());
    console.log("Reversing...");
}

function responsiveMenu() {
    var elem = $('#tn')[0];
    if (elem.className === "topnav") {
        elem.className += " responsive";
    } else {
        elem.className = "topnav";
    }
}

//if (screen.innerWidth >= 600) reverseElementOrder();

//function setFlag(){
//    if (c && flag == false) flag = true;
//    else flag = false;
//    console.log(window.innerWidth);
//}

$(window).resize(function() {
    if (lastWindowSize > 600 && window.innerWidth <= 600){ 
        reverseElementOrder(); 
        console.log("Reversing...");
    }
    if (lastWindowSize < 600 && window.innerWidth >= 600){ 
        reverseElementOrder(); 
        console.log("Reversing...");
    }
    console.log("Last: " + lastWindowSize);
    console.log("Curr: " + window.innerWidth);
    lastWindowSize = window.innerWidth;
});


var flag;
var lastWindowSize = window.innerWidth;

//Ready function
$(function () {
    "use strict";
    
    //setFlag();
    console.log("Ready!");
});