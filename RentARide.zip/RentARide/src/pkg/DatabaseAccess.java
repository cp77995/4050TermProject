package pkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseAccess {
	
	static final String DRIVE_NAME = "com.mysql.jdbc.Driver";
	static final String CONNECTION_URL = "jdbc:mysql://localhost:3306/rentaride";
	static final String DB_CONNECTION_USERNAME = "root";
	static final String DB_CONNECTION_PASSWORD = "password";
	
	//Establish a connection to the database.
	public static Connection connect() {
		Connection con = null;
		try {
			Class.forName(DRIVE_NAME);
			con = DriverManager.getConnection(CONNECTION_URL, DB_CONNECTION_USERNAME, DB_CONNECTION_PASSWORD);
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	//Must edit to return a String
	public static String retrieve(Connection con, String q){
		
		//Build the query
		String query = "Select * FROM users WHERE username=\"" + q + "\"";
		
		//Create the ResultSet and set it to null
		ResultSet rset = null;

		//Start the table string
		String table = "<table>";
		
		try {
			//Create a statement
			Statement stmt = con.createStatement();
			
			//Execute mySQL query
			rset = stmt.executeQuery(query);
			
			//Create ResultSetMetaData object for reading later
			ResultSetMetaData rsMetaData = rset.getMetaData();
			
			//Get number of columns
		    int numCol = rsMetaData.getColumnCount();
		    
		    //Create the head of the document, the top of the table
		    table += "<tr>";
		    for(int i=1; i<numCol; i++){
		    	table += "<td><b>" + rsMetaData.getColumnName(i) + "</b></td>";
		    }
		    table += "<tr>";
		    
		    //Build the table's contents
			while(rset.next()){   
			    table += "<tr>";
			    for(int i=1; i<numCol; i++){
			    	table += "<td>"; 
			    	table += rset.getString(i); 
					table += "</td>";
				}
			    table += "</tr>";
			}
			table+="</table>";
			
			return table;
			
		} catch (SQLException e) {
			table += "ERROR: NOT FOUND";
			e.printStackTrace();
			return table;
		}
		
	}
}	